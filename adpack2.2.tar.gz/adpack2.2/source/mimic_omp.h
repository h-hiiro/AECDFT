 
 
int omp_get_thread_num   (void);
int omp_get_num_threads  (void);
int omp_get_num_procs    (void);
void omp_set_num_threads (int i);
